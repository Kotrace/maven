package dev.kotrace

import kotlinx.coroutines.currentCoroutineContext
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext

/**
 * Which [LogLevel]s are kept when appended to a span. Set once at startup; the default drops DEBUG so an
 * uninstrumented build stays quiet. A test or a scoped flow can override per-trace with [CaptureConfig].
 *
 * A `Set`, not a threshold: "INFO + ERROR without DEBUG" is not expressible as a single cut-off.
 */
object KotraceLog {
    @Volatile
    var captureLevels: Set<LogLevel> = setOf(LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR)
}

/**
 * Per-flow override of [KotraceLog.captureLevels], read only by the suspend [logSpan] (it rides the
 * `CoroutineContext`, so it cannot reach the non-suspend [logSpanHere]). Seed it beside the root span
 * for a scoped capture level; absent, the global default applies.
 */
class CaptureConfig(val levels: Set<LogLevel>) :
    AbstractCoroutineContextElement(Key) {
    companion object Key : CoroutineContext.Key<CaptureConfig>
}

/**
 * Appends a log [message] to the span active on the coroutine — the primary, suspend log verb. Filtered
 * by the ambient [CaptureConfig] or, absent one, [KotraceLog.captureLevels]; [message] is a lambda so a
 * dropped level costs nothing to build. No active span → no-op (safe to call anywhere).
 */
suspend fun logSpan(level: LogLevel, message: () -> String) {
    val levels = currentCoroutineContext()[CaptureConfig]?.levels ?: KotraceLog.captureLevels
    if (level !in levels) return
    currentCoroutineContext()[SpanContext]?.span?.let { it.events += SpanEvent(level, message(), System.nanoTime()) }
}

/**
 * Non-suspend log verb for code running **on** a coroutine's thread without a `coroutineContext` handle —
 * a synchronous factory or callback invoked mid-flow. Resolves the span through the [currentSpan]
 * ThreadLocal bridge and filters by the global [KotraceLog.captureLevels] (no context for a per-flow
 * override). No active span → no-op.
 */
fun logSpanHere(level: LogLevel, message: () -> String) {
    currentSpan()?.log(level, message)
}

/**
 * Appends to a span **held directly** — for a bridge that already carries the span across a thread
 * boundary (the OkHttp request tag, a Room callback), where neither the coroutine context nor the
 * [currentSpan] ThreadLocal is available on the executing thread. Filters by [KotraceLog.captureLevels].
 */
fun Span.log(level: LogLevel, message: () -> String) {
    if (level !in KotraceLog.captureLevels) return
    events += SpanEvent(level, message(), System.nanoTime())
}
