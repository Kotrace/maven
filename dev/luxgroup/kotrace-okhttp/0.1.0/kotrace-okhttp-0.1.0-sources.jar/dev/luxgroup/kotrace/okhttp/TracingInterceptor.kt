package dev.luxgroup.kotrace.okhttp

import dev.luxgroup.kotrace.Span
import dev.luxgroup.kotrace.SpanStatus
import dev.luxgroup.kotrace.TRACEPARENT_HEADER
import dev.luxgroup.kotrace.toTraceparent
import okhttp3.Interceptor
import okhttp3.Response

/**
 * Injects the W3C `traceparent` for the request's [Span] tag, so the backend continues the same trace —
 * mobile↔backend correlation with no OpenTelemetry dependency.
 *
 * The span is attached to the request **at the call site**, not here: an interceptor runs on OkHttp's
 * own thread and cannot read the coroutine's `SpanContext` (Trap 1). A request with no span tag passes
 * through untouched, so this is safe to install on every client. Pair with [TracingCallFactory], which
 * places the tag from the coroutine thread.
 */
class TracingInterceptor : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val span = chain.request().tag(Span::class.java)
            ?: return chain.proceed(chain.request())

        val request = chain.request().newBuilder()
            .header(TRACEPARENT_HEADER, span.toTraceparent())
            .build()

        val response = chain.proceed(request)
        span.attributes["http.status"] = response.code.toString()
        if (!response.isSuccessful) span.status = SpanStatus.ERROR
        return response
    }
}